 * * ASHEN for MC 1.20.3-1.21.4 * *
     release v1.11

	- Thanks for checking out Ashen. This pack is still in its early stages, and will likely see a revamp of many of its
		textures at some point (animated textures like lava, water, and seagrass are particularly likely to be redone
		eventually). This is my first real foray into pixel art and pack work, so much will likely change as my own
		skills and techniques evolve. If you have any feedback, please don't hesitate to drop me a line on the 
		project's Curseforge, Modrinth, or PlanetMinecraft pages, or the pack's Discord server: https://discord.gg/yuwrZQpGDk

	- This pack is mostly intended to respect Vanilla Minecraft's fantasy style, but with my own approach to it. I try to
		reserve more high-fantasy textures for otherworldly blocks and concepts -- anything relating to the Nether, 
		for instance, is intended to read as more alien than overworld blocks, which I hope to keep more "down-to-earth." 


 * * Disclaimers & Troubleshooting * *

	- I have taken a good chunk of inspiration from Maffhew's "Excalibur" (https://www.curseforge.com/minecraft/texture-packs/excalibur),
		Stitch's "Faithless" (https://www.curseforge.com/minecraft/texture-packs/faithless), and Jicklus's, well, "Jicklus" 
		(https://www.curseforge.com/minecraft/texture-packs/jicklus). Go check them out, they're all fantastic packs by great people.
		My original inspiration, though, was Rhodox's "Painterly Pack," which was my go-to texture pack when I first started playing 
		the game back in 2011. Unfortunately, Rhodox's site has since closed down, so the pack is no longer really available. 
		To my mind, it was a classic.
		Pour one out.

	- This pack is intended to be used alongside Fancy Graphics. If your bushy leaves appear dark and lack transparency/detail,
		this is a result of Fast Graphics. If you can't use Fancy Graphics, or if you do not want to have "bushy" leaves,
		please use Ashen Simple Foliage. Place this above Ashen in your load order to revert the leaf blocks to their Vanilla-style 
		models. These models will still retain their random rotation and variants.
